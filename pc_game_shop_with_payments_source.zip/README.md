# P&C Game Shop

Android demo app source. Includes KBZPay and WavePay transfer-account display and a local demo order list.

- KBZPay: 09691869813 — Yin Yin Aung
- WavePay: 09683640259 — Su Po Po Aung

Orders are stored only on the same device/browser. This demo does not verify payments, accept screenshot uploads, sync customer orders to a remote admin, or automatically deliver game top-ups. Admin PIN is a demo-only client-side PIN (2468), not secure for production.

Upload the files in this ZIP to the GitHub repository root (extract first; do not upload the ZIP as a single file), then run the GitHub Actions workflow to build a debug APK.
